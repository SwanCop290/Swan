    # cursor.execute('INSERT INTO communities (communityname, owned_by) VALUES (%s ,%s,)', (community_name, user_id))
        # cursor.execute('insert into comuser (communityname , community_id,username,user_id)=(%s,%s,%s,%s)'())
        # # Fetch one record and return result