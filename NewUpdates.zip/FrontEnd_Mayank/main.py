from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re
app = Flask(__name__)  
app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'password'
app.config['MYSQL_DB'] = 'swanDB'
mysql = MySQL(app)



@app.route('/signup', methods=['GET', 'POST'])
def register():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username", "password" and "email" POST requests exist (user submitted form)
    if request.method == 'POST' and 'User_Name' in request.form and 'Password' in request.form and 'email' in request.form:
        # Create variables for easy access
        username = request.form['User_Name']
        password = request.form['Password']
        email = request.form['email']
    elif request.method == 'POST':
        # Form is empty... (no POST data)
        msg = 'Please fill out the form!'
    # Show registration form with message (if any)
    return render_template('register.html', msg=msg)


@app.route('/login', methods=['GET', 'POST'])
def login():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username" and "password" POST requests exist (user submitted form)
    if request.method == 'POST' and 'User_Name' in request.form and 'Password' in request.form:
        # Create variables for easy access
        username = request.form['User_Name']
        password = request.form['Password']
        # Check if account exists using MySQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM Users WHERE User_Name = %s AND Password = %s', (username, password,))
        # Fetch one record and return result
        account = cursor.fetchone()
        # If account exists in accounts table in out database
        if account:
            # Create session data, we can access this data in other routes
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
            # Redirect to home page
            return 'Logged in successfully!'
        else:
            # Account doesnt exist or username/password incorrect
            msg = 'Incorrect username/password!'
    # Show the login form with message (if any)
    return render_template('index.html', msg=msg)


@app.route('/login/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return redirect(url_for('login'))




@app.route('/')              ##########
def home():

    is_owner=False
    if 'loggedin' in session :
        # We need all the account info for the user so we can display it on the profile page
        is_owner = True
    
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM posts')
    acc = cursor.fetchall()

    return render_template('index.html', account=acc,is_owner=is_owner)



@app.route('/<int:id>/profile',methods=['GET'])   ########
def profile(id):
    # Check if user is loggedin
    
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM accounts WHERE id = %s', (id,))
    account = tuple(cursor.fetchall())

    # Show the profile page with account info
    return render_template('users-profile.html', account=account[0])






@app.route('/<int:user_id>/profile/myposts',methods=['GET'])   ########
def myposts(user_id):
    # Check if user is loggedin 

    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM posts WHERE id = %s', (user_id,))
    userposts = cursor.fetchone()
    # Show the profile page with account info
    return render_template('myposts.html', userposts=userposts)


@app.route('/<int:user_id>/profile/myfriends',methods=['GET','delete'])                        ###########
def myfriends(user_id):

    if request.method == 'GET':
        # We need all the account info for the user so we can display it on the profile page

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM friends WHERE user_id = %s', (user_id,))
        myfriend = cursor.fetchall()
        # Show the profile page with account info
        return render_template('myfriends.html', myfriend=myfriend)

    elif request.method == 'delete':
        # Create variables for easy access
        Friend = request.form['Friend_ID']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('delete from friends where friend_id=%s,user_id=%s', (Friend,user_id))

        return render_template('myfriends.html')

    # elif request.method == 'POST':
    #     # Form is empty... (no POST data)
    #     msg = 'Please fill out the form!'
    #     # Show registration form with message (if any)
    #     return render_template('myfriends.html',msg=msg)

    return render_template('myfriends.html')

@app.route('/<int:id>/profile/mycommunity',methods=['GET','POST'])                        ###########
def mycommunity(id):

    if request.method == 'GET':
        # We need all the account info for the user so we can display it on the profile page
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM communities WHERE id = %s', (id,))
        account = cursor.fetchall()
        # Show the profile page with account info
        return render_template('mycommunity.html', account=account)

    elif request.method == 'POST' and 'community_ID' in request.form :
        # Create variables for easy access
        community_ID = request.form['community_ID']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT into Friends ( )',)

        return render_template('mycommunity.html')

    elif request.method == 'POST':
        # Form is empty... (no POST data)
        msg = 'Please fill out the form!'
        # Show registration form with message (if any)
        return render_template('mycommunity.html',msg=msg)

    return render_template('mycommunity.html')




@app.route('/<int:id>/setting',methods=['GET','POST'])       ######
def setting(id):

    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM accounts WHERE id = %s', (id,))
    account = cursor.fetchone()

    # Show the profile page with account info
    return render_template('profilesetting.html', account=account)





@app.route('/<int:id>/setting/changepassword',methods=['GET','POST'])       #NOPE#
def changepassword(id):

    if request.method == 'GET' :
        return render_template('profilesetting.html')

    else:

        password = request.form['Password']
        newpassword = request.form['Password']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('UPDATE accounts SET Password = %s,  WHERE id = %s AND Password = %s', (newpassword, id, password,))
        # Fetch one record and return result

        return redirect(url_for('profile'))

@app.route('/<int:id>/setting/editprofile',methods=['GET','POST'])       #NOPE#
def editprofile(id):

    if request.method == 'GET' :
        return render_template('profilesetting.html')

    else:


        user_name = request.form['Password']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('UPDATE accounts SET user_name = %s,  WHERE id = %s ', (user_name, id,))
        # Fetch one record and return result

        return redirect(url_for('profilesetting'))


@app.route('/<int:id>/createpost')       #########
def createpost(id):

    community_id = request.form['community_id']
    post_id = request.form['post_id']
    data = request.form['data']

    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('INSERT INTO posts (community_id, post_id, data,) VALUES (%s ,%s, %s,)', (community_id, post_id, data,))
    # Fetch one record and return result

    return redirect(url_for('home'))

@app.route('/<int:id>/createcommunity')       #########
def createcommunity(id):

    community_name = request.form['community_name']
    owner= request.form['id']

    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('INSERT INTO communities (community_name, owner) VALUES (%s ,%s,)', (community_name, owner))
    # Fetch one record and return result

    return redirect(url_for('home'))





@app.route('/posts/<int:Post_ID>',methods=['GET', 'DELETE'])       #############
def singlepost(Post_ID):

    if request.method == 'GET':

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM posts where Post_ID= %s',(Post_ID))
        acc = cursor.fetchall()

        return render_template('singlepost.html', account=acc)

    elif request.method == 'DELETE':

        if 'loggedin' not in session:

            msg ='You are not logged in'

            return render_template('singlepost.html',msg=msg)

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT id FROM posts where Post_ID= %s',(Post_ID))
        owner = cursor.fetchall()

        if owner != session['id']:
            msg ='cannot delete this post'

            return render_template('singlepost.html',msg=msg)

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('DELETE FROM posts where Post_ID= %s',(Post_ID))

        return redirect(url_for('home'))

    return redirect(url_for('home'))

@app.route('/posts/gaming')
def gaming():

    type = 'Gaming'
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM posts where type= %s',(type))
    account = cursor.fetchall()

    return render_template('Gaming.html',account=account)

@app.route('/posts/business')
def business():

    type = 'business'
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM posts where type= %s',(type))
    account = cursor.fetchall()

    return render_template('Business.html',account=account)

@app.route('/posts/others')
def others():

    type = 'others'
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM posts where type= %s',(type))
    account = cursor.fetchall()

    return render_template('Gaming.html',account=account)
    

@app.route('/community/<int:community_ID>',methods=['GET', 'DELETE'])       #############
def singlecommunity(community_ID):

    if request.method == 'GET':
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM communities where community_ID= %s',(community_ID))
        acc = cursor.fetchall()

        return render_template('singlecommunity.html', community=acc)

    elif request.method == 'DELETE':

        if 'loggedin' not in session:

            msg ='You are not logged in'

            return render_template('singlecommunity.html',msg=msg)

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT owner FROM communities where community_ID= %s',(community_ID))
        owner = cursor.fetchall()

        if owner != session['id']:
            msg ='cannot delete this post'

            return render_template('singlecommunity.html',msg=msg)

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('DELETE FROM communities where community_ID= %s',(community_ID))

        return redirect(url_for('home'))

    return redirect(url_for('home'))


@app.route('/otherprofile/<int:id>',methods=['GET']) 
def otherprofile(id):

    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM accounts where id= %s',(id))
    accounts = cursor.fetchall()

    cursor.execute('SELECT * FROM communities where id= %s',(id))
    comm = cursor.fetchall()


    return render_template('otherprofile.html',accounts=accounts,comm=comm)





# @app.route('/<int:id>/Profile/Friends',methods=['GET','POST'])                        ###########
# def friend(id):

#     if 'loggedin' in session and request.method == 'GET':
#         # We need all the account info for the user so we can display it on the profile page
#         cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#         cursor.execute('SELECT * FROM Friends WHERE id = %s', (id,))
#         account = cursor.fetchall()
#         # Show the profile page with account info
#         return render_template('friend.html', account=account)

#     elif request.method == 'POST' and 'Friend_ID' in request.form :
#         # Create variables for easy access
#         Friend = request.form['Friend_ID']

#         cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#         cursor.execute('INSERT into Friends ( )', (Friend,id))

#         return render_template('friend.html')

#     elif request.method == 'POST':
#         # Form is empty... (no POST data)
#         msg = 'Please fill out the form!'
#         # Show registration form with message (if any)
#         return render_template('friend.html',msg=msg)

#     return render_template('friend.html')


# @app.route('/<int:id>/Friends/<int:Friend_ID>',methods=['POST'])          #############
# def addfriend(id,Friend_ID):
#     # Check if "username", "password" and "email" POST requests exist (user submitted form)
#     if request.method == 'POST' and 'Friend_ID' in request.form :
#         # Create variables for easy access
#         Friend = request.form['Friend_ID']

#         cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#         cursor.execute('INSERT into Friends ( )', (Friend,id))

#         return redirect(url_for('friend'))
      
    # elif request.method == 'POST':
    #     # Form is empty... (no POST data)
    #     msg = 'Please fill out the form!'
    #     # Show registration form with message (if any)
    #     return redirect(url_for('friend'))

    # # User is not loggedin redirect to login page
    # return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)




